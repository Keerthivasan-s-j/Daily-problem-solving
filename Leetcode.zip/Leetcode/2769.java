class Solution {
    public int theMaximumAchievableX(int num, int t) {
        return num + (t * 2);
    }
}